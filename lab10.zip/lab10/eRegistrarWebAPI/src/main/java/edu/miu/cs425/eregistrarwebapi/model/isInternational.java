package edu.miu.cs425.eregistrarwebapi.model;

public enum isInternational {
    yes, no

}
